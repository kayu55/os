#!/bin/bash
User=$1
Days=$3
iplimit=$2

IP=$(curl -sS ipv4.icanhazip.com)


egrep "^$User" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
current_exp=$(chage -l $User | grep "Account expires" | cut -d: -f2 | xargs)

if [[ "$current_exp" == "never" ]]; then
  base_date=$(date +%s)
else
  base_date=$(date -d "$current_exp" +%s)
fi

Days_Detailed=$(( $Days * 86400 ))
Expire_On=$(( $base_date + $Days_Detailed ))
Expiration=$(date -u --date="1970-01-01 $Expire_On sec GMT" +%Y/%m/%d)
Expiration_Display=$(date -u --date="1970-01-01 $Expire_On sec GMT" '+%d %b %Y')
tgl=$(date -d "$Days days" +"%d")
bln=$(date -d "$Days days" +"%b")
thn=$(date -d "$Days days" +"%Y")
expe="$tgl $bln, $thn"
expi=$(cat /etc/xray/ssh | grep -wE "$User" | cut -d " " -f6-8)
sed -i "s/$expi/$expe/" /etc/xray/ssh
passwd -u $User
usermod -e  $Expiration $User
clear
echo -e "  RENEW SSH"
echo -e " Remark      : $User "
echo -e " Limit Ip    : ${iplimit} Devic "
echo -e " Expiry in  : $Expiration_Display "
exit 0
else
echo -e "  RENEW SSH FAILED USER IS GONE"
exit 1
fi